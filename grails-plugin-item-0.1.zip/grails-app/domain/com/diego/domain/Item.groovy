package com.diego.domain

class Item {

	String nome
	String descricao
	int qtdd
	
    static constraints = {
    }
}
