package com.diego.services

import grails.transaction.Transactional

@Transactional
class HelloWorldService {

    def String hello(String name){
		return "hello my fellow ${name}"
	}
}
