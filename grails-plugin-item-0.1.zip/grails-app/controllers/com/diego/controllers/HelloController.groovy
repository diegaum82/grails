package com.diego.controllers

import com.diego.services.HelloWorldService

class HelloController {

	def helloWorldService
	
    def index() { 
		def msg = helloWorldService.hello('cumpadi')
		render msg
	}
}
