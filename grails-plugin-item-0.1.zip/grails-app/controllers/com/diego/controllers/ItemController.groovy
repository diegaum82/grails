package com.diego.controllers

import com.diego.domain.Item

class ItemController {
	static scaffold = Item
}
